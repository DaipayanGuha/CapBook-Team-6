package com.cg.capbook.beans;

import javax.persistence.Embeddable;
import javax.persistence.ManyToOne;

@Embeddable
public class Friend {
	
	private String friendName;

	public CapBookUser friend;
	
	public Friend() {}

	public Friend(String friendName, CapBookUser friend) {
		super();
		this.friendName = friendName;
		this.friend = friend;
	}
	
	public String getFriendName() {
		return friendName;
	}

	public void setFriendName(String friendName) {
		this.friendName = friendName;
	}

	public CapBookUser getFriend() {
		return friend;
	}

	public void setFriend(CapBookUser friend) {
		this.friend = friend;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((friend == null) ? 0 : friend.hashCode());
		result = prime * result + ((friendName == null) ? 0 : friendName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Friend other = (Friend) obj;
		if (friend == null) {
			if (other.friend != null)
				return false;
		} else if (!friend.equals(other.friend))
			return false;
		if (friendName == null) {
			if (other.friendName != null)
				return false;
		} else if (!friendName.equals(other.friendName))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Friend [friendName=" + friendName + ", friend=" + friend + "]";
	}
}
