package com.cg.capbook.beans;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;


@Entity
public class CapBookUser 
{
	@Id
	private String email;
	private String firstName;
	private String lastName;
	private String password;
	private String gender;
	private String dob;
	private String securityQuestion;
	private String securityAnswer;
	private String profilePic;
	private String mobileNum;
	private String address;
	
	private String department;
	private String designation;
	private String expertise;
	private String experience;
	
	@Embedded
	public List<Friend> friends = new ArrayList<Friend>();
	
	@MapKey
	@OneToMany(mappedBy="user")
	public List<Post> posts = new ArrayList<Post>();	
	
	public CapBookUser() {
		super();
	}

	public CapBookUser(String email, String firstName, String lastName, String password, String gender, String dob,
			String securityQuestion, String securityAnswer, String mobileNum) {
		super();
		this.email = email;
		this.firstName = firstName;
		this.lastName = lastName;
		this.password = password;
		this.gender = gender;
		this.dob = dob;
		this.securityQuestion = securityQuestion;
		this.securityAnswer = securityAnswer;
		this.mobileNum = mobileNum;
	}

	public CapBookUser(String email, String firstName, String lastName, String password, String gender, String dob,
			String securityQuestion, String securityAnswer, String profilePic, String mobileNum) {
		super();
		this.email = email;
		this.firstName = firstName;
		this.lastName = lastName;
		this.password = password;
		this.gender = gender;
		this.dob = dob;
		this.securityQuestion = securityQuestion;
		this.securityAnswer = securityAnswer;
		this.profilePic = profilePic;
		this.mobileNum = mobileNum;
	}
	
	public CapBookUser(String department, String designation, String expertise, String experience) {
		super();
		this.department = department;
		this.designation = designation;
		this.expertise = expertise;
		this.experience = experience;
	}

	public CapBookUser(String email, String firstName, String lastName, String password, String gender, String dob,
			String securityQuestion, String securityAnswer, String profilePic, String mobileNum, String address,
			String department, String designation, String expertise, String experience, List<Post> posts) {
		super();
		this.email = email;
		this.firstName = firstName;
		this.lastName = lastName;
		this.password = password;
		this.gender = gender;
		this.dob = dob;
		this.securityQuestion = securityQuestion;
		this.securityAnswer = securityAnswer;
		this.profilePic = profilePic;
		this.mobileNum = mobileNum;
		this.address = address;
		this.department = department;
		this.designation = designation;
		this.expertise = expertise;
		this.experience = experience;
		this.posts = posts;
	}

	public CapBookUser(String email, String firstName, String lastName, String password, String gender, String dob,
			String securityQuestion, String securityAnswer, String profilePic, String mobileNum, String address,
			String department, String designation, String expertise, String experience, List<Friend> friends,
			List<Post> posts) {
		super();
		this.email = email;
		this.firstName = firstName;
		this.lastName = lastName;
		this.password = password;
		this.gender = gender;
		this.dob = dob;
		this.securityQuestion = securityQuestion;
		this.securityAnswer = securityAnswer;
		this.profilePic = profilePic;
		this.mobileNum = mobileNum;
		this.address = address;
		this.department = department;
		this.designation = designation;
		this.expertise = expertise;
		this.experience = experience;
		this.friends = friends;
		this.posts = posts;
	}

	public List<Friend> getFriends() {
		return friends;
	}

	public void setFriends(List<Friend> friends) {
		this.friends = friends;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getSecurityQuestion() {
		return securityQuestion;
	}

	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
	}

	public String getSecurityAnswer() {
		return securityAnswer;
	}

	public void setSecurityAnswer(String securityAnswer) {
		this.securityAnswer = securityAnswer;
	}

	public String getProfilePic() {
		return profilePic;
	}

	public void setProfilePic(String profilePic) {
		this.profilePic = profilePic;
	}

	public String getMobileNum() {
		return mobileNum;
	}

	public void setMobileNum(String mobileNum) {
		this.mobileNum = mobileNum;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getExpertise() {
		return expertise;
	}

	public void setExpertise(String expertise) {
		this.expertise = expertise;
	}

	public String getExperience() {
		return experience;
	}

	public void setExperience(String experience) {
		this.experience = experience;
	}

	public List<Post> getPosts() {
		return posts;
	}

	public void setPosts(List<Post> posts) {
		this.posts = posts;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result + ((department == null) ? 0 : department.hashCode());
		result = prime * result + ((designation == null) ? 0 : designation.hashCode());
		result = prime * result + ((dob == null) ? 0 : dob.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((experience == null) ? 0 : experience.hashCode());
		result = prime * result + ((expertise == null) ? 0 : expertise.hashCode());
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((gender == null) ? 0 : gender.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + ((mobileNum == null) ? 0 : mobileNum.hashCode());
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		result = prime * result + ((posts == null) ? 0 : posts.hashCode());
		result = prime * result + ((profilePic == null) ? 0 : profilePic.hashCode());
		result = prime * result + ((securityAnswer == null) ? 0 : securityAnswer.hashCode());
		result = prime * result + ((securityQuestion == null) ? 0 : securityQuestion.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CapBookUser other = (CapBookUser) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (department == null) {
			if (other.department != null)
				return false;
		} else if (!department.equals(other.department))
			return false;
		if (designation == null) {
			if (other.designation != null)
				return false;
		} else if (!designation.equals(other.designation))
			return false;
		if (dob == null) {
			if (other.dob != null)
				return false;
		} else if (!dob.equals(other.dob))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (experience == null) {
			if (other.experience != null)
				return false;
		} else if (!experience.equals(other.experience))
			return false;
		if (expertise == null) {
			if (other.expertise != null)
				return false;
		} else if (!expertise.equals(other.expertise))
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (gender == null) {
			if (other.gender != null)
				return false;
		} else if (!gender.equals(other.gender))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		if (mobileNum == null) {
			if (other.mobileNum != null)
				return false;
		} else if (!mobileNum.equals(other.mobileNum))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (posts == null) {
			if (other.posts != null)
				return false;
		} else if (!posts.equals(other.posts))
			return false;
		if (profilePic == null) {
			if (other.profilePic != null)
				return false;
		} else if (!profilePic.equals(other.profilePic))
			return false;
		if (securityAnswer == null) {
			if (other.securityAnswer != null)
				return false;
		} else if (!securityAnswer.equals(other.securityAnswer))
			return false;
		if (securityQuestion == null) {
			if (other.securityQuestion != null)
				return false;
		} else if (!securityQuestion.equals(other.securityQuestion))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "CapBookUser [email=" + email + ", firstName=" + firstName + ", lastName=" + lastName + ", password="
				+ password + ", gender=" + gender + ", dob=" + dob + ", securityQuestion=" + securityQuestion
				+ ", securityAnswer=" + securityAnswer + ", profilePic=" + profilePic + ", mobileNum=" + mobileNum
				+ ", address=" + address + ", department=" + department + ", designation=" + designation
				+ ", expertise=" + expertise + ", experience=" + experience + ", posts=" + posts + "]";
	}
}