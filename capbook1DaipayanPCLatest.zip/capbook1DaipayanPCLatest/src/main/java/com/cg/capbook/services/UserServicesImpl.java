package com.cg.capbook.services;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.cg.capbook.beans.CapBookUser;
import com.cg.capbook.beans.Friend;
import com.cg.capbook.beans.Post;
import com.cg.capbook.daoservices.PostDAO;
import com.cg.capbook.daoservices.UserDAO;
import com.cg.capbook.exceptions.IncorrectAnswerException;
import com.cg.capbook.exceptions.IncorrectPasswordException;
import com.cg.capbook.exceptions.IncorrectUsernameException;
import com.cg.capbook.exceptions.NewPasswordSimilarToOldException;
import com.cg.capbook.exceptions.PasswordMismatchException;


@Component("userServices")
public class UserServicesImpl implements UserServices
{
	@Autowired
	UserDAO userDAO;
	@Autowired
	PostDAO postDAO;
	
	public static String UPLOADED_FOLDER = "src/main/resources/static/img/";
	@Override
	public CapBookUser acceptUserDetails(CapBookUser user){

		String password = user.getPassword();
		user.setPassword(this.encryptLogic(password));

		String securityAnswer = user.getSecurityAnswer();
		user.setSecurityAnswer(this.encryptLogic(securityAnswer));
	//	List<Friend> friends = new ArrayList<Friend>();
		List<CapBookUser> users = getAllFriends(user.getEmail());
		for(int i=0;i<users.size();i++) 
		{ 
			Friend friend = new Friend(users.get(i).getFirstName(),users.get(i));
			user.getFriends().add(friend);
			}

		user = userDAO.save(user);
		return user;
	}

	/*
	 * public List<Friend> addFriends(String email){ List<CapBookUser> users =
	 * userDAO.findAllUsers(email); List<Friend> friends = new ArrayList<Friend>();
	 * for(int i=0;i<users.size();i++) { Friend friend = new Friend(FRIEND_ID++,
	 * users.get(i).getFirstName(), users.get(i)); friends.add(friend); }
	 * 
	 * return friends;
	 * 
	 * }
	 */
	public String encryptLogic(String stringToEncrypt) {
		StringBuffer encryptedBuffer = new StringBuffer();

		for(int i=0;i<stringToEncrypt.length();i++) {
			encryptedBuffer.append((int)stringToEncrypt.charAt(i)+2);
		}
		String encryptedString = (encryptedBuffer.reverse()).toString();
		return encryptedString;
	}

	@Override
	public CapBookUser checkPassword(String email, String password) throws IncorrectPasswordException, IncorrectUsernameException {
		CapBookUser user = this.getUserDetails(email);
		if(user.getPassword().equals(encryptLogic(password)))
			return user;
		else
			throw new IncorrectPasswordException("Incorrect Password");
	}

	@Override
	public CapBookUser loginUser(CapBookUser user) throws IncorrectPasswordException, IncorrectUsernameException {
		if(this.checkPassword(user.getEmail(), user.getPassword()).equals(null)) {
			throw new IncorrectUsernameException("Incorrect Userame in login");
		}
		return this.getUserDetails(user.getEmail());
	}

	@Override
	public CapBookUser forgetPassword(String email) throws IncorrectUsernameException {
		return this.getUserDetails(email);
	}

	@Override
	public CapBookUser getUserDetails(String email) throws IncorrectUsernameException {
		return userDAO.findById(email).orElseThrow(()->new IncorrectUsernameException("Incorrect Username"));
	}

	@Override
	public boolean checkSecurityAnswer(String email1, String securityAnswer) throws IncorrectAnswerException, IncorrectUsernameException {
		CapBookUser user = this.getUserDetails(email1);
		if(user.getSecurityAnswer().equalsIgnoreCase(encryptLogic(securityAnswer))) {
			return true;
		}
		throw new IncorrectAnswerException("Your Answer Is Not Correct");
	}

	@Override
	public boolean changeForgettedPassword(String email1,String newPassword, String confirmPassword) throws PasswordMismatchException, IncorrectUsernameException {
		CapBookUser user = this.getUserDetails(email1);
		if(!newPassword.equals(confirmPassword))
			throw new PasswordMismatchException("Password Mismatch");
		user.setPassword(encryptLogic(confirmPassword));
		userDAO.save(user);
		return true;
	}

	@Override
	public boolean setNewPassword(String email, String oldPassword, String newPassword, String confirmPassword) throws IncorrectUsernameException, PasswordMismatchException, NewPasswordSimilarToOldException {
		CapBookUser user = this.getUserDetails(email);

		if(!encryptLogic(oldPassword).equals(user.getPassword())) {

			throw new PasswordMismatchException("Password Mismatch");
		}
		if(encryptLogic(newPassword).equals(encryptLogic(oldPassword))) {

			throw new NewPasswordSimilarToOldException("New Password Should'nt match old passowrd");
		}
		if(!newPassword.equals(confirmPassword) ) {
			throw new PasswordMismatchException("Password Mismatch");
		}
		user.setPassword(encryptLogic(confirmPassword));
		userDAO.save(user);
		return true;
	}

	@Override
	public CapBookUser saveImage(String email,MultipartFile imageFile) throws IOException, IncorrectUsernameException {
		CapBookUser user = this.getUserDetails(email);
		//String folder = "/folder/";
		byte[] bytes = imageFile.getBytes();
		Path path = Paths.get(UPLOADED_FOLDER + imageFile.getOriginalFilename());
		//imageFile.transferTo(path);
		Files.write(path,bytes);
		String path1= path.toString();
		user.setProfilePic("/img/" + imageFile.getOriginalFilename());
		return userDAO.save(user);
	}

	@Override
	public CapBookUser makeNewPost(String email, String postme) throws IncorrectUsernameException {
		CapBookUser user = getUserDetails(email);		
		Post post = new Post(postme,(java.time.LocalDateTime.now()), 0, 0, user, null);
		post.setPostType("text");
		postDAO.save(post);
		user.getPosts().add(post);
		return userDAO.save(user);
	}

	@Override
	public CapBookUser makeNewImagePost(String email, MultipartFile postme) throws IncorrectUsernameException, IOException {
		CapBookUser user = getUserDetails(email);
		byte[] bytes = postme.getBytes();
		Path path = Paths.get(UPLOADED_FOLDER + user.getFirstName()+"/" + postme.getOriginalFilename());
		Files.write(path,bytes);
		Post post = new Post("/img/"+user.getFirstName() + "/" + postme.getOriginalFilename(),(java.time.LocalDateTime.now()), 0, 0, user, null);
		post.setPostType("image");
		postDAO.save(post);
		String path1 = path.toString();
		user.getPosts().add(post);
		return userDAO.save(user);

	}

	@Override
	public CapBookUser updatetProfileDetails(String email,CapBookUser user) throws IncorrectUsernameException {
		CapBookUser user1 = getUserDetails(email);
		
		if(!user.getFirstName().isEmpty())	
			user1.setFirstName(user.getFirstName());
		
		if(!user.getLastName().isEmpty())
			user1.setLastName(user.getLastName());
		
		if(!user.getMobileNum().isEmpty())
			user1.setMobileNum(user.getMobileNum());
		
		if(!user.getAddress().isEmpty())
			user1.setAddress(user.getAddress());
		//		  user.proDetails.setDepartment(user.proDetails.getDepartment());
		//		  user.proDetails.setDesignation(user.proDetails.getDesignation());
		//		  user.proDetails.setExpertise(user.proDetails.getExpertise());
		//		  user.proDetails.setExperience(user.proDetails.getExperience());
		return userDAO.save(user1);
	}

	@Override
	public CapBookUser updateProfessionalDetails(String email,CapBookUser user) throws IncorrectUsernameException {
		CapBookUser user1 = getUserDetails(email);

		if(!user.getDepartment().isEmpty())	
			user1.setDepartment(user.getDepartment());

		if(!user.getDesignation().isEmpty())	
			user1.setDesignation(user.getDesignation());

		if(!(user.getExperience().isEmpty()))	
			user1.setExperience(user.getExperience());

		if(!user.getExpertise().isEmpty())	
			user1.setExpertise(user.getExpertise());

		//		  user.proDetails.setDepartment(user.proDetails.getDepartment());
		//		  user.proDetails.setDesignation(user.proDetails.getDesignation());
		//		  user.proDetails.setExpertise(user.proDetails.getExpertise());
		//		  user.proDetails.setExperience(user.proDetails.getExperience());
		//user1.setProDetails(pro);
		//user1.setProDetails(pro);

		return userDAO.save(user1);
	}


	@Override
	public CapBookUser noOfLikesAndDislikes(String email, int thisPost,String operation) throws IncorrectUsernameException {
		CapBookUser user = getUserDetails(email);
		Post post = postDAO.findById(thisPost).orElseThrow(()->new IncorrectUsernameException("Heyyyyy"));
		if(operation.equals("Likes")) {
			if(post.getLikeStatus().equals("enable")) {
				post.setPostLikes((post.getPostLikes()+1));
				if(post.getPostDislikes()!=0) {
					post.setPostDislikes((post.getPostDislikes()-1));
					post.setDislikeStatus("enable");
					}
				post.setLikeStatus("disable");
				
			}
		}
		
		else if(operation.equalsIgnoreCase("Dislikes")) {
			if(post.getDislikeStatus().equals("enable")) {
				post.setPostDislikes((post.getPostDislikes()+1));
				if(post.getPostLikes()!=0) {
				post.setPostLikes((post.getPostLikes()-1));
				post.setLikeStatus("enable");
				}
				post.setDislikeStatus("disable");	
				
			}
		}
		else {
			throw new IncorrectUsernameException("Else Part here");
		}

		postDAO.save(post);

		return userDAO.save(user);
	}	
	
	@Override
	public List<CapBookUser> getAllFriends(String email) {
		return userDAO.findAllUsers(email);
		
	}

	@Override
	public List<CapBookUser> getUserAllDetails() {
		return userDAO.findAll();
	}

	@Override
	public List<CapBookUser> searchAccounts(String email, String firstName) throws IncorrectUsernameException {
		return userDAO.searchAccountDao(firstName);
	}
}