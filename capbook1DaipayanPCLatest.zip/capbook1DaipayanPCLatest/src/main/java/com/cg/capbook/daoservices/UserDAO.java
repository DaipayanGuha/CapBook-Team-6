package com.cg.capbook.daoservices;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.capbook.beans.CapBookUser;
import com.cg.capbook.beans.CapBookUser;

public interface UserDAO extends JpaRepository<CapBookUser, String>
{
	@Query(value="from CapBookUser u where u.email!=:email")
	List<CapBookUser> findAllUsers(@Param("email") String email);
	
	@Query(value="from CapBookUser u where u.firstName=:firstName")
	List<CapBookUser> searchAccountDao(@Param("firstName") String firstName);
}
