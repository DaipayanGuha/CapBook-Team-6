package com.cg.capbook.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Comments
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int commentId;
	private String comments;

	@ManyToOne
	private Post post;
	public Comments() {}
	
	

	public Comments(String comments) {
		super();
		this.comments = comments;
	}



	public Comments(int commentId, String comments, Post post) {
		super();
		this.commentId = commentId;
		this.comments = comments;
		this.post = post;
	}



	public Comments(int commentId, String comments) {
		super();
		this.commentId = commentId;
		this.comments = comments;
	}

	public int getCommentId() {
		return commentId;
	}

	public void setCommentId(int commentId) {
		this.commentId = commentId;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + commentId;
		result = prime * result + ((comments == null) ? 0 : comments.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Comments other = (Comments) obj;
		if (commentId != other.commentId)
			return false;
		if (comments == null) {
			if (other.comments != null)
				return false;
		} else if (!comments.equals(other.comments))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Comments [commentId=" + commentId + ", comments=" + comments + "]";
	}



}
